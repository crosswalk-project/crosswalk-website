aar is a sample maven project to deal with aar


