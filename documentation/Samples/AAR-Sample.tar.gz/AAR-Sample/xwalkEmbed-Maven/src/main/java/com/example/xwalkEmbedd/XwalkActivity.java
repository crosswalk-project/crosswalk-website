package com.example.xwalkEmbedd;

import android.os.Bundle;
import org.xwalk.core.XWalkView;
import android.util.Log;
import android.app.Activity;

public class XwalkActivity extends Activity {
    private XWalkView mXWalkView;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mXWalkView = (XWalkView) findViewById(R.id.activity_main);
        mXWalkView.load("http://crosswalk-project.org/", null);
    }
}
